# replit.md

## Overview

This is a full-stack web application built on a monorepo structure using React (frontend) and Express (backend). The project appears to be a starter/template application with a comprehensive UI component library already set up. Based on context found in nested documentation, this template has been used to build a TRF3 court session management system (roteiro de sessão), but the current top-level code at `MadLowestAmoeba/` is a clean template state — the router has no active pages yet, and the storage layer uses in-memory storage.

The repository contains nested copies of the same template at various directory depths (`MadLowestAmoeba/`, `MadLowestAmoeba/DelightfulMediocreDeletions/`, `MadLowestAmoeba/DelightfulMediocreDeletions/appreg/`, etc.). **The active working project is at the root `MadLowestAmoeba/` level.**

Key capabilities already wired up:
- Full shadcn/ui component library (accordion, dialog, form, table, chart, etc.)
- React Query for server state
- Wouter for client-side routing
- Drizzle ORM schema with PostgreSQL dialect
- In-memory storage (swappable for PostgreSQL)
- Drag-and-drop via @dnd-kit
- AgentMail integration available as a dependency

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

- **Framework**: React 18 with TypeScript, bundled via Vite
- **Routing**: Wouter (lightweight client-side routing). Add new pages in `client/src/App.tsx` inside the `<Switch>` block.
- **State Management**: TanStack React Query v5 for server state. The `queryClient` is configured with `staleTime: Infinity` and no auto-refetch.
- **UI Components**: shadcn/ui ("new-york" style) with Radix UI primitives. All components live in `client/src/components/ui/`. Custom CSS variables defined in `client/src/index.css` control theming — **note: all color variables are currently set to `red` as placeholders and need to be replaced with real HSL values**.
- **Styling**: Tailwind CSS with custom design tokens. Dark mode via class strategy. Custom utility classes like `hover-elevate` and `active-elevate-2` are referenced in components.
- **Forms**: React Hook Form + `@hookform/resolvers` with Zod validation
- **Drag and Drop**: @dnd-kit/core + @dnd-kit/sortable for reorderable lists
- **Path Aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend Architecture

- **Framework**: Express.js with TypeScript, run via `tsx` in development
- **Entry Point**: `server/index.ts` creates the HTTP server, registers routes, and sets up request logging for all `/api/*` routes
- **Routes**: Defined in `server/routes.ts`. All API routes must be prefixed with `/api`. Currently empty — add routes here.
- **Storage Layer**: Abstracted behind `IStorage` interface in `server/storage.ts`. Currently uses `MemStorage` (in-memory Map). To switch to PostgreSQL, implement a `DatabaseStorage` class using Drizzle and swap the exported `storage` instance.
- **Static Serving**: In production, `server/static.ts` serves the built client from `dist/public/`. In development, Vite middleware handles HMR via `server/vite.ts`.
- **Build**: `script/build.ts` runs Vite for the client and esbuild for the server. Server dependencies in the `allowlist` array are bundled to reduce cold start time.

### Data Storage

- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Defined in `shared/schema.ts` (shared between client and server)
- **Current Schema**: Only a `users` table with `id` (UUID), `username`, and `password` fields
- **Migrations**: Output to `./migrations/`. Run `npm run db:push` to sync schema to database.
- **Config**: `drizzle.config.ts` reads `DATABASE_URL` from environment. Will throw at startup if not set.
- **Current State**: The app uses `MemStorage` by default. PostgreSQL is configured but not yet connected to the storage layer.

### Authentication

No authentication system is currently implemented. The schema has a `users` table, and the `IStorage` interface supports user lookup by username, but no session management or auth middleware is wired up. The build script includes `passport`, `passport-local`, `express-session`, and `connect-pg-simple` in its bundle allowlist, suggesting these are intended for future auth.

### Development vs Production

- **Dev**: `npm run dev` → `tsx server/index.ts` → Express + Vite middleware with HMR
- **Production**: `npm run build` → Vite builds client to `dist/public/`, esbuild bundles server to `dist/index.cjs` → `npm start`

## External Dependencies

### Email Integration
- **AgentMail** (`agentmail` package): Available as a dependency for email inbox management. Used in the TRF3 implementation for receiving case request emails.

### UI & Component Libraries
- **Radix UI**: Full set of headless primitives (dialog, dropdown, select, etc.)
- **shadcn/ui**: Component wrappers around Radix with Tailwind styling
- **Lucide React**: Icon library
- **Recharts**: Chart components (via `chart.tsx`)
- **Embla Carousel**: Carousel component
- **Vaul**: Drawer/sheet component
- **cmdk**: Command palette component

### Database
- **PostgreSQL**: Via `pg` driver + Drizzle ORM. Requires `DATABASE_URL` environment variable.

### Fonts (Google Fonts, loaded in `index.html`)
- Architects Daughter, DM Sans, Fira Code, Geist Mono

### Replit-Specific Plugins (dev only)
- `@replit/vite-plugin-runtime-error-modal`: Shows runtime errors as overlay
- `@replit/vite-plugin-cartographer`: Replit code navigation
- `@replit/vite-plugin-dev-banner`: Dev environment banner

### Other Notable Dependencies in Build Allowlist
- `openai`, `@google/generative-ai`: AI integrations (not yet wired up)
- `stripe`: Payment processing (not yet wired up)
- `multer`: File upload handling
- `nodemailer`: Email sending
- `xlsx`: Spreadsheet generation
- `ws`: WebSocket support
- `express-rate-limit`: Rate limiting middleware